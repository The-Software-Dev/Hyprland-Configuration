# Setup Instructions

## Step 1 — Create a FREE Pusher account
1. Go to https://pusher.com and sign up for free
2. Click "Create app"
3. Name it anything (e.g. "wietse-site")
4. Choose cluster "eu"
5. Click "Create app"
6. Go to "App Keys" tab — you need these 4 values:
   - app_id
   - key
   - secret
   - cluster

## Step 2 — Add Pusher key to your HTML
Open `public/index.html` and find this line near the bottom:

```
var PUSHER_KEY = 'YOUR_PUSHER_KEY';
var PUSHER_CLUSTER = 'eu';
```

Replace `YOUR_PUSHER_KEY` with your actual key from Pusher.

## Step 3 — Deploy to Vercel
1. Go to https://vercel.com and log in
2. Click "Add New Project"
3. Upload this entire folder OR push it to a GitHub repo and connect that
4. Before deploying, add these Environment Variables in Vercel:
   - PUSHER_APP_ID → your app_id
   - PUSHER_KEY → your key
   - PUSHER_SECRET → your secret
   - PUSHER_CLUSTER → eu
5. Click Deploy!

## Step 4 — Done!
- Open your site on 2 devices
- Press Ctrl+D on one
- Type: linuxisdabest
- Press any dev button — it fires on BOTH screens instantly

## Dev Mode Commands
- SHUTDOWN → blacks out all screens with "THIS WEBSITE IS IN SHUTDOWN"
- ACTIVATE ALL → party + Caesar + confetti + lightning forever on all screens
- JUMPSCARE → Caesar fills every screen with AGHHHHH
