const Pusher = require('pusher');

const pusher = new Pusher({
  appId: '2167186',
  key: '2dfe6bac827561e2cf9b',
  secret: '925252b6ef0ddcfa92bc',
  cluster: 'eu',
  useTLS: true
});

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { command } = req.body;

  if (!command) {
    return res.status(400).json({ error: 'No command provided' });
  }

  await pusher.trigger('devmode', 'command', { command });
  res.status(200).json({ ok: true });
};
